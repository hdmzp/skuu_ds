# segmentation_example_pytorch — 12주차 실습 (2026 개정)

기존 `building_segmentation.py`(TensorFlow/Keras) 를 PyTorch 2.x 로 옮기고, 최신 학습 관행
(Dice+CE 손실, mIoU 평가, AMP, OneCycleLR, 백본 교체)과 SAM 기반 pseudo-label 실습을 추가했습니다.

## 설치
```bash
pip install -r requirements.txt
```

## 1. 라벨 변환 (labelme → VOC 인덱스 마스크)
```bash
python labelme2voc.py cad_img_v3 data_annotated2 --labels labels.txt
python -c "from dataset import npy_to_index_png; npy_to_index_png('data_annotated2/SegmentationClass', 'data_annotated2/SegmentationClassPNG3')"
```
`labels.txt` 순서: `__ignore__`, `_background_`, ow, iw, of, cw, ef, st, oo (배경 = 0, 총 8클래스; 기존 Keras 코드의 `NUM_CLASSES = 7` 은 `oo` 가 빠진 값이므로 주의).

## 2. 학습
```bash
python train_seg.py --data data_annotated2 --arch deeplabv3plus --encoder resnet50 --epochs 30      # 기존 구조
python train_seg.py --data data_annotated2 --arch segformer     --encoder mit_b2   --lr 6e-5         # 트랜스포머 백본
python train_seg.py --data data_annotated2 --arch unet          --encoder resnet34 --ignore_bg_in_miou
```
결과: `runs/<arch>_<encoder>_<time>/best.pt`, `history.json`, `curves.png`

## 3. 예측·시각화
```bash
python predict.py --ckpt runs/deeplabv3plus_resnet50_xxxx/best.pt --images data_annotated2/JPEGImages --out preds
```

## 4. SAM pseudo-label (상자 프롬프트 → 마스크)
```bash
python train_sam_pseudolabel.py --json_dir cad_img_v3 --images data_annotated2/JPEGImages --labels labels.txt \
       --out data_annotated2/SegmentationClassSAM
python train_seg.py --data data_annotated2 --mask_sub SegmentationClassSAM
```

## 과제
1. 백본 3종(resnet50 / mit_b2 / efficientnet-b3)의 val mIoU·학습 시간 비교표 작성
2. 손실 ablation: CE 만 / Dice 만 / CE+Dice 의 클래스별 IoU (특히 소수 클래스 ef, st)
3. 사람 라벨 vs SAM pseudo-label 로 학습한 모델의 mIoU·경계 정확도 비교, 실패 사례 분석
